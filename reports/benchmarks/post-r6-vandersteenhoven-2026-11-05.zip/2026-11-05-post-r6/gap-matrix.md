# Actualisatie van de 28 oorspronkelijke opportunities

Status op basis van de nieuwe productiecrawl van 5 november 2026. Geïmplementeerde functies zijn niet automatisch bewezen SF-pariteit. Scores voor resterend bouwwerk staan afzonderlijk bij de aanbevelingen.

| ID | Onderdeel | Status na R6 | Bewijs / resterend gat | Vervolg |
|---|---|---|---|---|
| G01 | Herpogingen en time-outs | Paginafase verbeterd; aparte doelen onvoldoende | 364 pagina-antwoorden, nul aanvraagfouten; SDK-downloadfout en vijf onderbroken doelen blijven onbekend. | N02 |
| G02 | Bestandsregister en bronrelaties | Aantoonbaar verbeterd | 631 bestandsdoelen; 35.687 referenties over beide doelsoorten; alle 119 directe SF-doelen in inventaris. | N01,N02 |
| G03 | Kapotte scripts/styles/afbeeldingen | Gedeeltelijk bevestigd | Drie van vier SDK-404’s bevestigd; vierde onbekend. Vier bestands-404’s in totale set. | N02,N03 |
| G04 | Externe linkstatus | Aanwezig, classificatiedefect | 70/70 externe SF-hyperlinkdoelen in register; 11 status-999-antwoorden worden onterecht pass. | N01 |
| G05 | Afbeeldingsgewicht en hergebruik | Referentie bevestigd; interpretatie uitbreiden | 11/11 zware referentieafbeeldingen met exacte bytegelijkheid; 115 aparte gewichtgroepen over hele site. | N03,N08 |
| G06 | Lege versus ontbrekende alt | Data bevestigd; beoordeling contextafhankelijk | 965 lege alt-attributen, nul ontbrekend; review- en naamcontroles, geen 965 bewezen defecten. | N03,N05 |
| G07 | Opgegeven afbeeldingsafmetingen | Referentiegegevens aanwezig | 965 afbeeldingsverwijzingen met breedte/hoogte en elementpad in gemeenschappelijke set. | — |
| G08 | Intrinsieke en weergegeven afmetingen | Browsersteekproef, geen SF-referentie | 179 browserafbeeldingselementen met intrinsieke dimensies; sitebrede browserdekking ontbreekt. | N04,N05,N08 |
| G09 | Linkpositie en DOM-context | Aantoonbaar verbeterd | 828/828 hyperlinkparen; bronpad, regio en target opgeslagen. Geen volledige frequentie-/locatorgelijkheidsclaim. | N11 |
| G10 | Lege en onduidelijke linknamen | Actieve analyse; browser gedeeltelijk | Statische naamregels en browser link-name op 15 pagina’s; browsercontext beperkt door externe fonts. | N03,N05 |
| G11 | Koppen en H2-context | Ruwe referentie reproduceerbaar; definities anders | 37 ruwe H1-na-H2-pagina’s; 22 eerste inhoudskop-geen-H1 en één inhoudsniveausprong. | N11 |
| G12 | Titellengte in tekens | Referentie bevestigd | 32/32 eerste titels >60 tekens; actieve title_too_long-regel. | — |
| G13 | Titelbreedte in pixels | Model aanwezig, niet SF-equivalent | 15 pixelschattingen; eigen font/600px tegenover eerder SF-overzicht met 561px. | N04,N11 |
| G14 | Overige metadata- en koplengte/plaatsing | Actief, beperkte SF-issue-exports | Vijf pagina’s met lange H1/H2 in cohort; title buiten head op calculator. | N11 |
| G15 | HTML-documentstructuur | Concrete referentie bevestigd | Eén calculator in cohort met geneste documentstructuur en metadata buiten head; drie in hele scan. | N03 |
| G16 | Open Graph en X Cards | Actieve extra diagnostiek | 56 onvolledige profielen per controletype in cohort; zakelijk belang afhankelijk van deelgebruik. | N03,N11 |
| G17 | Hoofdinhoud en leesbaarheid | Beperkte dekking | 22 expliciete main-selecties, 37 fallbacks; 48/59 leesbaarheid onbekend, drie juridische expertgevallen. | N06 |
| G18 | Beveiligingsheaders | Per-headerregels; SF-waarden niet beschikbaar | Vijf afzonderlijke afwezigheidssignalen in cohort; geen exploit- of compliancebewijs. | N03,N11 |
| G19 | URL-hygiëne | Actieve diagnostiek | Parameters en schrijfwijze worden afzonderlijk beoordeeld; geen universele foutgrens. | N11 |
| G20 | Identieke versus tegenstrijdige canonical | Extractie bevestigd, conflicten niet live getest | 59 self-canonicals; geen conflictexemplaar in cohort. Gescheiden regels bestaan. | N11 |
| G21 | Sitemapdekking en herkomst | Live bevestigd | 327/327 geprobeerd; 318 ook via links, negen alleen sitemap; herkomst niet afgeknipt. | — |
| G22 | Browseronderzoek standaard | Actief, selectie/dekking onvoldoende | 15/20 budget benut, alle gedeeltelijk; calculator niet geselecteerd; vijf reserveplaatsen ongebruikt. | N04,N05 |
| G23 | Benchmarkexports en regressiecorpus | Deze benchmark reproduceerbaar; corpus smal | Bevroren snapshot, checksums en offline script; slechts één site en onvolledige SF-exports. | N10,N11 |
| G24 | Gestructureerde gegevens | Implementatie beperkt, niet live gevalideerd | Geen ondersteunde markup in gemeenschappelijke set; twee beperkte rich-result-profielen en synthetische tests. | N09,N11 |
| G25 | Concrete herstelopdrachten | Workflow aanwezig, nog te veel versnippering | 182 groepen worden 182 voorstellen; 115 afbeeldinggroepen en drie losse SDK-opdrachten. | N03,N10 |
| G26 | Scoredekking en onzekerheid | Zichtbaar; toepasselijkheid nog verbeteren | Techniek 77,0% en geen cijfer; content 84 bij 98,9%; UX 42,9%; privacy 0%. | N01,N07 |
| G27 | HTTP-headerbewijs | Selectief aanwezig, geen SF-gelijkheidsbewijs | Veilige headerselectie opgeslagen; oorspronkelijke SF-headerexport bevat alleen adressen. | N11 |
| G28 | Externe target=_blank-links | Actieve contextuele adviesregel | Negen cohortpagina’s met aanvullend rel-advies; geen claim dat moderne browserbescherming ontbreekt. | N11 |
